$(function() {
	$('p.slide').readmore({ //вызов плагина
	speed: 250, //скорость раскрытия скрытого текста (в миллисекундах)
	maxHeight: 70, //высота раскрытой области текста (в пикселях)
	heightMargin: 16, //избегание ломания блоков, которые больше maxHeight (в пикселях)
	moreLink: '<a href="#" class="morelink">know more <i class="fas fa-arrow-right"></i></a>', //ссылка "Читать далее", можно переименовать
	lessLink: '<a href="#" class="morelink"><i class="fas fa-times"></i></a>' //ссылка "Скрыть", можно переименовать
});
	$(document).ready(function(){
		$('[data-toggle="popover"]').popover({
			html: true,
			placement: 'bottom',

			modifiers: {
				flip: {
					behavior: 'bottom',
				},
				preventOverflow: {
					boundariesElement: '.teamer',
				},

			},
		}); 
	});

	$('.carousel-sync').on('slide.bs.carousel', function(ev) {
    // get the direction, based on the event which occurs
    var dir = ev.direction == 'right' ? 'prev' : 'next';
    // get synchronized non-sliding carousels, and make'em sliding
    $('.carousel-sync').not('.sliding').addClass('sliding').carousel(dir);
	});
	$('.carousel-sync').on('slid.bs.carousel', function(ev) {
    // remove .sliding class, to allow the next move
    $('.carousel-sync').removeClass('sliding');
});
});
